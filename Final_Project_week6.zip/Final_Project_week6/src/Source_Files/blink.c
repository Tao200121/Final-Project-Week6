/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

//#include "sl_simple_led.h"
//#include "sl_simple_led_instances.h"
#include "os.h"
#include "blink.h"
#include "em_emu.h"
#include "queue.h"
#include "glib.h"
#include "sl_board_control.h"
#include "sl_board_control_config.h"

/*******************************************************************************
 ***************************  LOCAL VARIABLES   ********************************
 ******************************************************************************/



//static OS_TCB tcb
static OS_TCB btn0_handler_tcb,
              btn1_handler_tcb,
              physics_task_tcb,
              idle_tcb,
              led_tcb,
              lcd_display_tcb,
              platform_tcb;

//static CPU_STK  stack[BLINK_TASK_STACK_SIZE]
static CPU_STK  button_stack[BUTTON_TASK_STACK_SIZE],
                physics_stack[PHYSICS_TASK_STACK_SIZE],
                idle_stack[IDLE_TASK_STACK_SIZE],
                led_stack[IDLE_TASK_STACK_SIZE],
                lcd_display_stack[LCD_DISPLAY_TASK_STACK_SIZE],
                platform_stack[platform_TASK_STACK_SIZE];


#define CHANNEL0  0
#define CHANNEL1  1
#define CHANNEL2  2
#define CHANNEL3  3



static OS_FLAG_GRP flag_grp1;    //flag group pointer
static OS_FLAG_GRP flag_grp2;

static OS_SEM btn0_semaphore,
              ball_timer_semaphore,
              platform_timer_semaphore,
              lcd_timer_semaphore,
              platform_semaphore,
              max_force_timer_semaphore,
              half_force_timer_semaphore;        //semaphore pointer

static OS_Q msg_q;              //message queue pointer

static OS_TMR ball_timer,
              platform_timer,
              lcd_timer,
              btn_timer,
              cool_down_timer,
              max_force_timer,
              half_force_timer;            //timer pointer

static OS_MUTEX mutex1;
static OS_MUTEX ball_mutex, platform_mutex, laser_mutex;

static GLIB_Context_t display;

char string[100];
char string2[100];
int current_speed;

int game_over_line = 6;

/*******************************************************************************
 *********************   LOCAL FUNCTION PROTOTYPES   ***************************
 ******************************************************************************/

//static void blink_task(void *arg);
static void btn0_handler_task(void *arg);
static void button1_handler_task(void *arg);
static void idle_task(void *arg);
static void physics_task(void *arg);
static void lcd_display_task(void *arg);
static void led_task(void *arg);
static void platform_task(void *arg);
static void create(void);

/*******************************************************************************
 **************************   GLOBAL FUNCTIONS   *******************************
 ******************************************************************************/

/***************************************************************************//**
 * Initialize blink example.
 ******************************************************************************/

struct platform platform1;
struct ball ball1;
struct laser laser1;
int make_turn = 0;
int previous_turn = 0;

//static volatile uint32_t msTicks;

bool sense0;
bool sense1;
bool sense2;
bool sense3;
int slide_time;

float delta_x, delta_y;
float delta_x_platform;
int32_t velocity_x, velocity_y;
int32_t velocity;
int32_t kinetic_e;


//void SysTick_Handler(void)
//{
//
//}

//enum alert_event_flag{
//  alert_event_flag0 = 2,
//  alert_event_flag1 = 4,
//  alert_event_flag3 = 8,
//  alert_event_flag4 = 16,
//};

struct node_t* speed;
int speed_change;

void GPIO_EVEN_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BUTTON0_pin);
  OSSemPost(&btn0_semaphore, OS_OPT_POST_1, &err);

}

void GPIO_ODD_IRQHandler(void)
{
//TODO///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  RTOS_ERR err;
  GPIO_IntClear(1 << BUTTON1_pin);
//  OSSemPost(&button1_semaphore, OS_OPT_POST_1, &err);

//  OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

  ball1.num_of_balls--;
  if((ball1.num_of_balls > 0) && (laser1.numActivations > 0))
    {

      ball1.ball_x_position = 20;
      ball1.ball_y_position = 20;
      ball1.vx = 2;
      ball1.vy = 0;
    }
  else if((ball1.num_of_balls == 0) && (laser1.numActivations > 0))
    {
      while(1)
        {
          GLIB_clear(&display);
          GLIB_drawStringOnLine(&display,
                                 "You Win",
                                 game_over_line,
                                 GLIB_ALIGN_CENTER,
                                 5,
                                 5,
                                 true);
           DMD_updateDisplay();
        }
    }


  else if(ball1.ball_y_position > 128)
    {
      while(1)
        {
          GLIB_clear(&display);
          GLIB_drawStringOnLine(&display,
                                "GAME OVER",
                                game_over_line,
                                GLIB_ALIGN_CENTER,
                                5,
                                5,
                                true);
          DMD_updateDisplay();
        }

    }
  laser1.numActivations--;

//  OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);




}

void blink_init(void)
{
  RTOS_ERR err;

  OSTaskCreate(&btn0_handler_tcb,
                 "button0 handler task",
                 btn0_handler_task,
                 DEF_NULL,
                 BUTTON_TASK_PRIO,
                 &button_stack[0],
                 (BUTTON_TASK_STACK_SIZE / 10u),
                 BUTTON_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

//  OSTaskCreate(&btn1_handler_tcb,
//                 "button1 handler task",
//                 button1_handler_task,
//                 DEF_NULL,
//                 BUTTON_TASK_PRIO,
//                 &button_stack[0],
//                 (BUTTON_TASK_STACK_SIZE / 10u),
//                 BUTTON_TASK_STACK_SIZE,
//                 0u,
//                 0u,
//                 DEF_NULL,
//                 (OS_OPT_TASK_STK_CLR),
//                 &err);

  OSTaskCreate(&physics_task_tcb,
                 "physics task",
                 physics_task,
                 DEF_NULL,
                 PHYSICS_TASK_PRIO,
                 &physics_stack[0],
                 (PHYSICS_TASK_STACK_SIZE / 10u),
                 PHYSICS_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&idle_tcb,
                 "idle task",
                 idle_task,
                 DEF_NULL,
                 IDLE_TASK_PRIO,
                 &idle_stack[0],
                 (IDLE_TASK_STACK_SIZE / 10u),
                 IDLE_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&led_tcb,
                 "led task",
                 led_task,
                 DEF_NULL,
                 LED_TASK_PRIO,
                 &led_stack[0],
                 (LED_TASK_STACK_SIZE / 10u),
                 LED_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&lcd_display_tcb,
                 "lcd display task",
                 lcd_display_task,
                 DEF_NULL,
                 LCD_DISPLAY_TASK_PRIO,
                 &lcd_display_stack[0],
                 (LCD_DISPLAY_TASK_STACK_SIZE / 10u),
                 LCD_DISPLAY_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);

  OSTaskCreate(&platform_tcb,
                 "platform task",
                 platform_task,
                 DEF_NULL,
                 platform_TASK_PRIO,
                 &platform_stack[0],
                 (platform_TASK_STACK_SIZE / 10u),
                 platform_TASK_STACK_SIZE,
                 0u,
                 0u,
                 DEF_NULL,
                 (OS_OPT_TASK_STK_CLR),
                 &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  create();
}



//timer callback function
void ball_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  OSSemPost(&ball_timer_semaphore, OS_OPT_POST_1, &err);

}

void platform_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  OSSemPost(&platform_timer_semaphore, OS_OPT_POST_1, &err);
}

void lcd_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  OSSemPost(&lcd_timer_semaphore, OS_OPT_POST_1, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

}

void max_force_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  OSSemPost(&max_force_timer_semaphore, OS_OPT_POST_1, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void half_force_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  OSSemPost(&half_force_timer_semaphore, OS_OPT_POST_1, &err);
  EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}

void btn_timer_callback(OS_TMR *timer, void *p_arg)
{
  RTOS_ERR err;
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);

  //start cooling down
  platform1.booster_ready_yet = 0;
  OSTmrStart(&cool_down_timer, &err);
  platform1.energy = 0;


}

void cool_down_timer_callback (OS_TMR *timer, void *p_arg)
{
  PP_UNUSED_PARAM(timer);
  PP_UNUSED_PARAM(p_arg);
  platform1.booster_ready_yet = 1;
}


//create timer
void create(void)
{
  RTOS_ERR err;
  //create message queue
  OSQCreate(&msg_q, "msg_q", MSG_Q_SIZE, &err);

  //create semaphore
//  OSSemCreate(&ball_semaphore, "ball semaphore", 0, &err);
  OSSemCreate(&ball_timer_semaphore, "ball timer semaphore", 0, &err);
  OSSemCreate(&platform_timer_semaphore, "platform timer semaphore", 0, &err);
  OSSemCreate(&lcd_timer_semaphore, "lcd timer semaphore", 0, &err);
  OSSemCreate(&btn0_semaphore, "btn0 semaphore", 0, &err);
//  OSSemCreate(&button1_semaphore, "btn1 semaphore", 1, &err);
  OSSemCreate(&platform_semaphore, "platform semaphore", 0, &err);
  OSSemCreate(&max_force_timer_semaphore, "max force timer semaphore", 0, &err);
  OSSemCreate(&half_force_timer_semaphore, "half force timer semaphore", 0, &err);

  //create flag group
  OSFlagCreate(&flag_grp1, "flag_grp1", 0, &err);
  OSFlagCreate(&flag_grp2, "flag_grp2", 0, &err);

  //create timer
  OSTmrCreate(&ball_timer, "ball timer", 0, TAU_PHYSICS, OS_OPT_TMR_PERIODIC, ball_timer_callback, NULL, &err);
  OSTmrCreate(&platform_timer, "platform timer", 0, TAU_PHYSICS, OS_OPT_TMR_PERIODIC, platform_timer_callback, NULL, &err);
  OSTmrCreate(&btn_timer, "btn timer", 10, 0, OS_OPT_TMR_ONE_SHOT, btn_timer_callback, NULL, &err);
  OSTmrCreate(&cool_down_timer, "cool down timer", 10, 0, OS_OPT_TMR_ONE_SHOT, cool_down_timer_callback, NULL, &err);
  OSTmrCreate(&lcd_timer, "lcd timer", 0, TAU_LCD, OS_OPT_TMR_PERIODIC, lcd_timer_callback, NULL, &err);
  OSTmrCreate(&max_force_timer, "max force timer", 30, 0, OS_OPT_TMR_ONE_SHOT, max_force_timer_callback, NULL, &err);
  OSTmrCreate(&half_force_timer, "half force timer", 15, 0, OS_OPT_TMR_ONE_SHOT, half_force_timer_callback, NULL, &err);

  //create mutex
  OSMutexCreate(&mutex1, "speed_setpoint_mutex", &err);
  OSMutexCreate(&ball_mutex, "ball mutex", &err);
  OSMutexCreate(&platform_mutex, "platform mutex", &err);
  OSMutexCreate(&laser_mutex, "laser mutex", &err);

  //start ball timer
}


/***************************************************************************//**
 * button0 task.
 ******************************************************************************/


static void btn0_handler_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  platform1.booster_ready_yet = 1;
  while(1)
    {
      OSSemPend(&btn0_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
      OSTmrStart(&btn_timer, &err);
      //energize
      if(platform1.booster_ready_yet == 1)
        {
          platform1.energy = 1;
        }
      else if (platform1.booster_ready_yet == 0)
        {
          platform1.energy = 0;
        }

    }

}


//static void button1_handler_task(void *arg)
//{
//  PP_UNUSED_PARAM(arg);
////  RTOS_ERR err;
////  while(1)
////    {
////      OSSemPend(&btn1_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
////      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
////      //call physics task
////    }
//  //wins automatically in this turn.
//}


static void physics_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;
  OSTmrStart(&ball_timer, &err);

  OSSemPend(&ball_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

  OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
  ball1.ball_x_position = 20;
  ball1.ball_y_position = 20;
  ball1.vx = 2;
  ball1.vy = 0;
  ball1.mass = 2;
  ball1.num_of_balls = 2;
  OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);

  OSMutexPend(&laser_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
  laser1.numActivations = 1;
  OSMutexPost(&laser_mutex, OS_OPT_POST_NONE, &err);
//  OSSemPost(&ball_semaphore, OS_OPT_POST_1, &err);    //post a semaphore to the lcd
  while(1)
    {
      OSSemPend(&ball_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

      OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
      delta_x = ball1.vx * TAU_PHYSICS;
      ball1.ball_x_position = x_position(ball1.ball_x_position, delta_x, &ball1);

      ball1.vy = ball1.vy + GRAVITY * TAU_PHYSICS;
      delta_y = ball1.vy * TAU_PHYSICS + 0.5 * GRAVITY * TAU_PHYSICS * TAU_PHYSICS;
      ball1.ball_y_position = y_position(ball1.ball_y_position, delta_y, &ball1, &platform1);


      OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);
//      OSSemPost(&ball_semaphore, OS_OPT_POST_1, &err);    //post a semaphore to the lcd

    }

}


static void platform_task(void *arg)
{
  PP_UNUSED_PARAM(arg);
  RTOS_ERR err;

  OSTmrStart(&platform_timer, &err);

  OSSemPend(&platform_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

  OSMutexPend(&platform_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
  platform1.platform_mass = 1.5;
  platform1.acceleration = 0;
  platform1.v = 1;
  platform1.length = 40;
  platform1.x_min = 10;
  platform1.x_max = platform1.x_min + platform1.length;
  platform1.y_position = RIGHT_WALL_Y2;
  OSMutexPost(&platform_mutex, OS_OPT_POST_NONE, &err);
  while(1)
  {
      OSSemPend(&platform_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

      OSMutexPend(&platform_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

      read_capsense();

      if((sense0 == true) && (sense1 == false) && (sense2 == false) && (sense3 == false))
        {
          platform1.force = MAX_FORCE;
          platform1.acceleration = -1 * platform1.force / platform1.platform_mass;
        }
      else if((sense0 == false) && (sense1 == true) && (sense2 == false) && (sense3 == false))
        {
          platform1.force = HALF_FORCE;
          platform1.acceleration = -1 * platform1.force / platform1.platform_mass;
        }
      else if((sense0 == false) && (sense1 == false) && (sense2 == true) && (sense3 == false))
        {
          platform1.force = HALF_FORCE;
          platform1.acceleration = platform1.force / platform1.platform_mass;
        }
      else if((sense0 == false) && (sense1 == false) && (sense2 == false) && (sense3 == true))
        {
          platform1.force = MAX_FORCE;
          platform1.acceleration = platform1.force / platform1.platform_mass;
        }
      else if((sense0 == false) && (sense1 == false) && (sense2 == false) && (sense3 == false))
        {
          platform1.force = 0;
          platform1.acceleration = platform1.force / platform1.platform_mass;
        }

      platform1.v = platform1.v + platform1.acceleration * TAU_PHYSICS;

      delta_x_platform = platform1.v * TAU_PHYSICS + 0.5 * platform1.acceleration * TAU_PHYSICS * TAU_PHYSICS;
      platform1.x_min = platform_position(platform1.x_min, platform1.x_max, delta_x_platform, &platform1);
      platform1.x_max = platform1.x_min + platform1.length;

      OSMutexPost(&platform_mutex, OS_OPT_POST_NONE, &err);

      OSSemPost(&platform_semaphore, OS_OPT_POST_1, &err);
  }
}

void read_capsense(void)
{

  CAPSENSE_Sense();
  sense0 = CAPSENSE_getPressed(CHANNEL0);
  sense1 = CAPSENSE_getPressed(CHANNEL1);
  sense2 = CAPSENSE_getPressed(CHANNEL2);
  sense3 = CAPSENSE_getPressed(CHANNEL3);
}






static void led_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;
  while(1)
    {
      OSSemPend(&platform_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
       if(platform1.force == HALF_FORCE)    //release all buttons
         {
//               OSTmrStart(&half_force_timer, &err);
//               OSTmrStart(&max_force_timer, &err);

               GPIO_PinOutSet(LED1_port, LED1_pin);
               GPIO_PinOutClear(LED0_port, LED0_pin);

//               OSSemPend(&half_force_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
               OSTimeDly(1000, OS_OPT_TIME_DLY, &err);

                GPIO_PinOutClear(LED0_port, LED0_pin);
                GPIO_PinOutClear(LED1_port, LED1_pin);

                OSTimeDly(1000, OS_OPT_TIME_DLY, &err);
//                OSSemPend(&max_force_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);

         }
       else if(platform1.force == MAX_FORCE)
         {
//           OSTmrStart(&max_force_timer, &err);

//               OSTmrStart(&half_force_timer, &err);
//               OSTmrStart(&max_force_timer, &err);

               GPIO_PinOutSet(LED1_port, LED1_pin);
               GPIO_PinOutClear(LED0_port, LED0_pin);

//               OSSemPend(&half_force_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
//
//                GPIO_PinOutClear(LED0_port, LED0_pin);
//                GPIO_PinOutClear(LED1_port, LED1_pin);

//                OSSemPend(&max_force_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
         }

       else
         {
           GPIO_PinOutClear(LED0_port, LED0_pin);
           GPIO_PinOutClear(LED1_port, LED1_pin);
         }
//       else if(result == alert_event_flag1)
//         {
//           GPIO_PinOutClear(LED0_port, LED0_pin);
//           GPIO_PinOutSet(LED1_port, LED1_pin);
//         }
//       else if(result == alert_event_flag4)
//         {
//           GPIO_PinOutSet(LED0_port, LED0_pin);
//           GPIO_PinOutSet(LED1_port, LED1_pin);
//         }
//       else if(result == alert_event_flag3)
//         {
//           GPIO_PinOutClear(LED0_port, LED0_pin);
//           GPIO_PinOutClear(LED1_port, LED1_pin);
//         }
    }

      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
}


static void lcd_display_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;
  OSTmrStart(&lcd_timer, &err);
  uint32_t status;

  /* Enable the memory lcd */
  status = sl_board_enable_display();
  EFM_ASSERT(status == SL_STATUS_OK);

  /* Initialize the DMD support for memory lcd display */
  status = DMD_init(0);
  EFM_ASSERT(status == DMD_OK);

  /* Initialize the glib context */
  status = GLIB_contextInit(&display);
  EFM_ASSERT(status == GLIB_OK);

  display.backgroundColor = White;
  display.foregroundColor = Black;

  /* Fill lcd with background color */
  GLIB_clear(&display);

  /* Use Narrow font */
  GLIB_setFont(&display, (GLIB_Font_t *) &GLIB_FontNarrow6x8);





  while(1){

      OSSemPend(&lcd_timer_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);
//      OSSemPend(&ball_semaphore, 0, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);


          OSMutexPend(&ball_mutex, ZERO, OS_OPT_PEND_BLOCKING, DEF_NULL, &err);


          if(ball1.ball_y_position > 128)
            {
              GLIB_clear(&display);
                  GLIB_drawStringOnLine(&display,
                                        "GAME OVER",
                                        game_over_line,
                                        GLIB_ALIGN_CENTER,
                                        5,
                                        5,
                                        true);
                  DMD_updateDisplay();
                  while(1);

            }
          else if(ball1.ball_y_position < 5)
            {
              ball1.num_of_balls--;
                if(ball1.num_of_balls == 0)
                  {
                    GLIB_clear(&display);
                    GLIB_drawStringOnLine(&display,
                                          "You Win",
                                          game_over_line,
                                          GLIB_ALIGN_CENTER,
                                          5,
                                          5,
                                          true);
                    DMD_updateDisplay();
                    while(1);
                  }
                else if(ball1.num_of_balls > 0)
                  {

//                    ball1.num_of_balls--;


                    ball1.ball_x_position = 20;
                    ball1.ball_y_position = 20;
                    ball1.vx = 2;
                    ball1.vy = 0;
                  }
            }
          GLIB_clear(&display);
          GLIB_drawLine(&display, LEFT_WALL_X1, LEFT_WALL_Y1, LEFT_WALL_X2, LEFT_WALL_Y2);
          GLIB_drawLine(&display, RIGHT_WALL_X1, RIGHT_WALL_Y1, RIGHT_WALL_X2, RIGHT_WALL_Y2);

          GLIB_drawCircle(&display, ball1.ball_x_position, ball1.ball_y_position, BALL_RAD);

          OSMutexPost(&platform_mutex, OS_OPT_POST_NONE, &err);
          GLIB_drawLine(&display, platform1.x_min, platform1.y_position, platform1.x_max, platform1.y_position);
          OSMutexPost(&platform_mutex, OS_OPT_POST_NONE, &err);

          DMD_updateDisplay();



          OSMutexPost(&ball_mutex, OS_OPT_POST_NONE, &err);





        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

        //direction

        OSTimeDly(10, OS_OPT_TIME_DLY, &err);
  }
}




static void idle_task(void *arg)
{
  PP_UNUSED_PARAM(arg);

  RTOS_ERR err;
  while (1)
  {
      EMU_EnterEM1();
//      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
  }
}
